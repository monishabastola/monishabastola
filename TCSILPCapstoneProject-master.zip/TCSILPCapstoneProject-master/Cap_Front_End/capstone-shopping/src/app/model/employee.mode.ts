export class Employee{
    
}