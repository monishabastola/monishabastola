export class User {
    unlocked:Number = 0;
    funds:Number = 0;
    firstName:string = "";
    lastName:string = "";
    dob:string = "";
    phone:number = 0;
    address:string = "";
    email:string = "";
    password:string = "";
    cPassword:string = "";
}