export class customer {
    
}